package com.Iniebiyo;

public class Main {

    public static void main(String[] args) {
        // write your code here

        TicketSupportGUI gui = new TicketSupportGUI();
    }
}